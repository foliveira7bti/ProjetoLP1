#ifndef VETERINARIO_H
#define VETERINARIO_H


#include <string>
#include <fstream>
#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

#include "funcionario.h"

using namespace std;

class Veterinario: public Funcionario {
	private:
		string crmv;

	public:
		Veterinario();
		~Veterinario();
		string getcrmv();
		void setcrmv(string c);
};

#endif