#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animal.h"
#include "reptil.h"

using namespace std;





Reptil::Reptil() {}
Reptil::~Reptil() {

}

bool Reptil::getVenenoso() {
	return venenoso;
}


void Reptil::setVenenoso(bool v) {
	venenoso = v;
}

string Reptil::getTipoVeneno() {
	return tipo_veneno;
}

void Reptil::setTipoVeneno(string tv) {
	tipo_veneno = tv;
}
