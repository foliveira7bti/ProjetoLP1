#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animalexotico.h"
#include "mamiferoexotico.h"

using namespace std;



MamiferoExotico::MamiferoExotico(){}
MamiferoExotico::~MamiferoExotico(){}