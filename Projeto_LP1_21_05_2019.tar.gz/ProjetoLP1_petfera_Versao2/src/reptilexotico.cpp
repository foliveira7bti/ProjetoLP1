#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animalexotico.h"
#include "reptilexotico.h"

using namespace std;





ReptilExotico::ReptilExotico(){}
ReptilExotico::~ReptilExotico(){}