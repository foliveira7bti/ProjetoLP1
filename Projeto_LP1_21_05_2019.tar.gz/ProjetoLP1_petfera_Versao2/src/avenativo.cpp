#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animalnativo.h"
#include "avenativo.h"

using namespace std;

AveNativo::AveNativo(){}
AveNativo::~AveNativo(){}