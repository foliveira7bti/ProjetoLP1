#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animalexotico.h"
#include "anfibioexotico.h"

using namespace std;

AnfibioExotico::AnfibioExotico(){}
AnfibioExotico::~AnfibioExotico(){}