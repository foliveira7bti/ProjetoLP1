#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animalnativo.h"
#include "anfibionativo.h"

using namespace std;

AnfibioNativo::AnfibioNativo() {}
AnfibioNativo::~AnfibioNativo(){}