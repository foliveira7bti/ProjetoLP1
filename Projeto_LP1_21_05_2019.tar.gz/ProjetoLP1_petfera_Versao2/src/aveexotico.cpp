#include <iostream>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <memory>
#include "animalexotico.h"
#include "aveexotico.h"

using namespace std;






AveExotico::AveExotico(){}
AveExotico::~AveExotico(){}