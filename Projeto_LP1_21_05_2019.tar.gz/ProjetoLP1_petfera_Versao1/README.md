para compilar:

1) make
2) ./bin/petfera
